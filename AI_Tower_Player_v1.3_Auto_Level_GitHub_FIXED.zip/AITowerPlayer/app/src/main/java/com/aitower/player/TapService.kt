package com.aitower.player

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class TapService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { holding = false }
    override fun onServiceConnected() { instance = this }
    companion object {
        @Volatile var instance: TapService? = null
        @Volatile var holding = false
    }

    fun tapAt(xRatio: Float, yRatio: Float) {
        val x = resources.displayMetrics.widthPixels * xRatio
        val y = resources.displayMetrics.heightPixels * yRatio
        val p = android.graphics.Path().apply { moveTo(x,y) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p,0,90)).build()
        dispatchGesture(g,null,Handler(Looper.getMainLooper()))
    }

    fun holdScreen() {
        if (holding) return
        holding = true
        val p = Path().apply { moveTo(resources.displayMetrics.widthPixels * .5f, resources.displayMetrics.heightPixels * .72f) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 60000)).build()
        dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { holding = false }
            override fun onCancelled(gestureDescription: GestureDescription?) { holding = false }
        }, Handler(Looper.getMainLooper()))
    }
    fun releaseScreen() {
        if (!holding) return
        val p = Path().apply { moveTo(resources.displayMetrics.widthPixels * .5f, resources.displayMetrics.heightPixels * .72f) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 1)).build()
        dispatchGesture(g, null, Handler(Looper.getMainLooper()))
        holding = false
    }
}
