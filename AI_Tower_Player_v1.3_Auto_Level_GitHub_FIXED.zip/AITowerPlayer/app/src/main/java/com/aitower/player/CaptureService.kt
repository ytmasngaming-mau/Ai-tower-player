package com.aitower.player

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.WindowManager
import kotlin.math.max

class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private val handler = Handler(Looper.getMainLooper())
    private var lastDecision = false
    private var decisionInitialized = false
    private var winArmed = true
    private var lastChange = 0L
    private var width = 0
    private var height = 0
    private var busy = false
    // Flow: 0=initial Smash popup, 1=gameplay, 2=level victory, 3=next-level Smash popup, 4=wait gameplay
    private var flowStage = 0
    private var stageFrames = 0
    private var lastFlowAction = 0L

    override fun onBind(intent: Intent?) = null
    override fun onCreate() { super.onCreate(); running = true; startForeground(7, notification()) }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getIntExtra("code", Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra("data", Intent::class.java) else @Suppress("DEPRECATION") intent?.getParcelableExtra("data")
        if (code == Activity.RESULT_OK && data != null) startCapture(code, data)
        return START_NOT_STICKY
    }

    private fun notification(): Notification {
        val channel = "tower_ai"
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(channel, "AI Tower Player", NotificationManager.IMPORTANCE_LOW))
        return Notification.Builder(this, channel).setContentTitle("AI Tower Player aktif").setContentText("Menganalisis layar game").setSmallIcon(android.R.drawable.ic_media_play).build()
    }

    private fun startCapture(code: Int, data: Intent) {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
        width = dm.widthPixels; height = dm.heightPixels
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(code, data)
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        display = projection?.createVirtualDisplay("TowerScreen", width, height, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, handler)
        handler.post(loop)
    }

    private val loop = object : Runnable {
        override fun run() {
            if (!running) return
            val img = reader?.acquireLatestImage()
            if (img != null) {
                try { analyze(img) } finally { img.close() }
            }
            handler.postDelayed(this, 100)
        }
    }

    private fun analyze(img: Image) {
        val plane = img.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val y0 = (height * (MainActivity.dangerY / 100f)).toInt().coerceIn(0, height - 1)
        val band = max(5, height / 100)
        val x0 = (width * .32f).toInt()
        val x1 = (width * .68f).toInt()
        var dark = 0
        var samples = 0
        for (y in (y0-band).coerceAtLeast(0)..(y0+band).coerceAtMost(height-1) step 3) {
            for (x in x0..x1 step 3) {
                val idx = y * rowStride + x * pixelStride
                if (idx + 2 < buffer.limit()) {
                    val r = buffer.get(idx).toInt() and 255
                    val g = buffer.get(idx+1).toInt() and 255
                    val b = buffer.get(idx+2).toInt() and 255
                    if (r < 62 && g < 62 && b < 70) dark++
                    samples++
                }
            }
        }
        val hazard = samples > 0 && dark.toFloat() / samples > MainActivity.threshold
        val now = System.currentTimeMillis()
        if (flowStage == 1 && (!decisionInitialized || (hazard != lastDecision && now - lastChange > 160))) {
            decisionInitialized = true
            lastDecision = hazard; lastChange = now
            val svc = TapService.instance
            if (hazard) svc?.releaseScreen() else svc?.holdScreen()
            MainActivity.status = if (hazard) "BAHAYA TERDETEKSI — LEPAS" else "JALUR AMAN — TAHAN"
        }

        // State machine khusus UI game dari screenshot pengguna (resolusi acuan 691x1536).
        // Tombol Level/Continue: sekitar 51.8%,81.6%. Tombol SMASH: sekitar 50%,47.3%.
        val nowFlow = System.currentTimeMillis()
        fun pixelMatch(xPct: Float, yPct: Float, tr: Int, tg: Int, tb: Int, tolerance: Int): Boolean {
            val x = (width * xPct).toInt().coerceIn(0, width - 1)
            val y = (height * yPct).toInt().coerceIn(0, height - 1)
            val idx = y * rowStride + x * pixelStride
            if (idx + 2 >= buffer.limit()) return false
            val r = buffer.get(idx).toInt() and 255
            val g = buffer.get(idx + 1).toInt() and 255
            val b = buffer.get(idx + 2).toInt() and 255
            return kotlin.math.abs(r-tr) <= tolerance && kotlin.math.abs(g-tg) <= tolerance && kotlin.math.abs(b-tb) <= tolerance
        }
        // Popup SMASH: titik tengah tombol berwarna cokelat-oranye pada screenshot kedua.
        val smashPopup = pixelMatch(.50f, .469f, 164, 99, 15, 55)
        // Layar Tower Smashed: titik tengah tombol Level 28 berwarna krem pada screenshot pertama.
        val victoryButton = pixelMatch(.518f, .817f, 239, 214, 192, 55)
        when (flowStage) {
            0 -> { // Mulai level: tekan SMASH
                stageFrames = if (smashPopup) stageFrames + 1 else 0
                if (stageFrames >= 3 && nowFlow - lastFlowAction > 1200) {
                    TapService.instance?.releaseScreen()
                    TapService.instance?.tapAt(.50f, .473f)
                    flowStage = 4; stageFrames = 0; lastFlowAction = nowFlow
                    MainActivity.status = "POPUP SMASH — MEMULAI LEVEL"
                }
            }
            1 -> { // Sedang bermain: tunggu tombol level berikutnya
                stageFrames = if (victoryButton) stageFrames + 1 else 0
                if (stageFrames >= 3 && nowFlow - lastFlowAction > 1500) {
                    TapService.instance?.releaseScreen()
                    TapService.instance?.tapAt(.518f, .817f)
                    flowStage = 3; stageFrames = 0; lastFlowAction = nowFlow
                    MainActivity.status = "LEVEL SELESAI — MEMBUKA LEVEL BERIKUTNYA"
                }
            }
            3 -> { // Setelah tombol Level ditekan, tunggu popup SMASH level berikutnya
                stageFrames = if (smashPopup) stageFrames + 1 else 0
                if (stageFrames >= 3 && nowFlow - lastFlowAction > 900) {
                    TapService.instance?.tapAt(.50f, .473f)
                    flowStage = 4; stageFrames = 0; lastFlowAction = nowFlow
                    MainActivity.status = "SMASH — LANJUT KE LEVEL BERIKUTNYA"
                }
            }
            4 -> { // Beri waktu animasi tower/gameplay dimulai sebelum deteksi bahaya aktif lagi
                if (nowFlow - lastFlowAction > 2500) {
                    flowStage = 1; stageFrames = 0
                    MainActivity.status = "GAMEPLAY OTOMATIS BERJALAN"
                }
            }
        }

    }

    override fun onDestroy() {
        running = false; handler.removeCallbacks(loop)
        TapService.instance?.releaseScreen()
        display?.release(); reader?.close(); projection?.stop()
        super.onDestroy()
    }
    companion object { @Volatile var running = false }
}
