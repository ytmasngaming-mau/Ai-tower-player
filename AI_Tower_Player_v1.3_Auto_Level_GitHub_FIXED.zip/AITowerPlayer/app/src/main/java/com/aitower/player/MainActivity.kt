package com.aitower.player

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

data class StepConfig(var name:String, var x:Int, var y:Int, var delay:Int, var enabled:Boolean=true)

class MainActivity : Activity() {
    companion object {
        @Volatile var dangerY = 29
        @Volatile var threshold = 0.025f
        @Volatile var status = "Siap"
        @Volatile var steps = mutableListOf<StepConfig>()
        @Volatile var winX = 90
        @Volatile var winY = 10
        @Volatile var winColor = "#00FF00"
        @Volatile var winTolerance = 35
        @Volatile var autoSequence = true
        @Volatile var autoIndex = 0
        private var appContext: Context? = null
        private val autoHandler = android.os.Handler(android.os.Looper.getMainLooper())

        fun onWinDetected() {
            val ctx = appContext ?: return
            if (!autoSequence) return
            if (autoIndex >= steps.size) {
                TapService.instance?.releaseScreen()
                ctx.stopService(Intent(ctx, CaptureService::class.java))
                status = "SEMUA TASK SELESAI"
                return
            }
            val step = steps[autoIndex]
            autoIndex++
            status = "LEVEL SELESAI — ${step.name} (${autoIndex}/${steps.size})"
            autoHandler.postDelayed({
                TapService.instance?.tapAt(step.x / 100f, step.y / 100f)
                status = "${step.name} dijalankan"
            }, step.delay.toLong())
        }
    }
    private val captureRequest = 41
    private lateinit var statusText: TextView
    private lateinit var stepsBox: LinearLayout
    private val prefs by lazy { getSharedPreferences("tower_player", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        appContext = applicationContext
        loadSteps()
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(20,20,20,20); setBackgroundColor(Color.rgb(245,247,250)) }
        root.addView(TextView(this).apply { text="AI TOWER PLAYER"; textSize=25f; setTextColor(Color.rgb(20,35,55)) })
        root.addView(TextView(this).apply { text="AI gameplay + urutan tombol manual"; textSize=14f })
        statusText=TextView(this).apply { text="Status: Siap"; textSize=17f; setPadding(0,14,0,14) }; root.addView(statusText)

        root.addView(TextView(this).apply { text="TASK 1 — MAIN GAME (deteksi area hitam)"; textSize=16f })
        val yLabel=TextView(this).apply { text="Garis deteksi bahaya: $dangerY% tinggi layar" }; root.addView(yLabel)
        root.addView(SeekBar(this).apply { max=70; progress=dangerY; setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s:SeekBar?,p:Int,u:Boolean){ dangerY=p; yLabel.text="Garis deteksi bahaya: $p% tinggi layar" }
            override fun onStartTrackingTouch(s:SeekBar?){}; override fun onStopTrackingTouch(s:SeekBar?){}
        }) })
        root.addView(TextView(this).apply { text="Sensitivitas deteksi hitam" })
        root.addView(SeekBar(this).apply { max=100; progress=25; setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s:SeekBar?,p:Int,u:Boolean){ threshold=p.coerceAtLeast(1)/1000f }
            override fun onStartTrackingTouch(s:SeekBar?){}; override fun onStopTrackingTouch(s:SeekBar?){}
        }) })

        root.addView(TextView(this).apply { text="AUTO LEVEL — KHUSUS UI GAME PADA SCREENSHOT"; textSize=17f; setPadding(0,18,0,5) })
        root.addView(TextView(this).apply { text="Alur otomatis: popup SMASH → main level → deteksi layar TOWER SMASHED → tekan tombol Level → popup SMASH berikutnya → main lagi. Koordinat tombol disesuaikan dari screenshot 691×1536. Task koordinat manual di bawah tetap tersedia untuk aksi tambahan, tetapi tidak diperlukan untuk alur Level/SMASH ini."; textSize=13f })
        root.addView(TextView(this).apply { text="TASK TAMBAHAN (OPSIONAL)"; textSize=17f; setPadding(0,18,0,5) })
        root.addView(TextView(this).apply { text="Tambahkan tombol tambahan jika diperlukan. Alur Level dan SMASH utama sudah otomatis."; textSize=13f })
        stepsBox=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        root.addView(stepsBox)
        root.addView(Button(this).apply { text="+ TAMBAH TASK TOMBOL"; setOnClickListener { addStepDialog() } })
        root.addView(Button(this).apply { text="SIMPAN URUTAN TASK"; setOnClickListener { saveSteps(); Toast.makeText(this@MainActivity,"Urutan disimpan",Toast.LENGTH_SHORT).show() } })
        root.addView(Button(this).apply { text="1. AKTIFKAN ACCESSIBILITY"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } })
        root.addView(Button(this).apply { text="2. MULAI AI GAMEPLAY"; setOnClickListener { startAI() } })
        root.addView(Button(this).apply { text="STOP SEMUA"; setOnClickListener { stopService(Intent(this@MainActivity,CaptureService::class.java)); statusText.text="Status: STOP"; } })
        root.addView(TextView(this).apply { text="CATATAN: deteksi layar menggunakan warna piksel pada titik tombol dari screenshot. Jika tampilan game, resolusi, atau tema berubah, deteksi bisa meleset. Uji beberapa level dulu dan awasi percobaan pertama."; textSize=13f; setPadding(0,16,0,0) })
        val scroll=ScrollView(this); scroll.addView(root); setContentView(scroll)
        renderSteps()
    }

    private fun addStepDialog() {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(24,8,24,8) }
        val name=EditText(this).apply { hint="Nama task, mis. Lanjut level 2"; setText("Lanjutkan") }
        val x=EditText(this).apply { hint="X layar (%) 0-100"; inputType=2; setText("50") }
        val y=EditText(this).apply { hint="Y layar (%) 0-100"; inputType=2; setText("85") }
        val delay=EditText(this).apply { hint="Jeda sebelum klik (ms)"; inputType=2; setText("500") }
        listOf(name,x,y,delay).forEach { box.addView(it) }
        AlertDialog.Builder(this).setTitle("Tambah task tombol").setView(box).setNegativeButton("Batal",null).setPositiveButton("Tambah"){_,_->
            steps.add(StepConfig(name.text.toString().ifBlank{"Task ${steps.size+2}"}, x.text.toString().toIntOrNull()?.coerceIn(0,100)?:50, y.text.toString().toIntOrNull()?.coerceIn(0,100)?:85, delay.text.toString().toIntOrNull()?.coerceIn(0,60000)?:500))
            saveSteps(); renderSteps()
        }.show()
    }

    private fun renderSteps() {
        stepsBox.removeAllViews()
        steps.forEachIndexed { index, step ->
            val row=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(10,10,10,10); setBackgroundColor(Color.WHITE) }
            row.addView(TextView(this).apply { text="TASK ${index+2}: ${step.name}  •  X ${step.x}% / Y ${step.y}%  •  jeda ${step.delay} ms"; textSize=14f })
            val buttons=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
            buttons.addView(Button(this@MainActivity).apply { text="EDIT"; setOnClickListener { editStep(index) } })
            buttons.addView(Button(this@MainActivity).apply { text="HAPUS"; setOnClickListener { steps.removeAt(index); saveSteps(); renderSteps() } })
            buttons.addView(Button(this@MainActivity).apply { text="LANJUT TASK"; setOnClickListener { runStep(index) } })
            row.addView(buttons); stepsBox.addView(row)
        }
    }

    private fun editStep(i:Int) {
        val s=steps[i]; val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(24,8,24,8) }
        val name=EditText(this).apply { setText(s.name) }; val x=EditText(this).apply { inputType=2; setText(s.x.toString()) }
        val y=EditText(this).apply { inputType=2; setText(s.y.toString()) }; val d=EditText(this).apply { inputType=2; setText(s.delay.toString()) }
        listOf(name,x,y,d).forEach { box.addView(it) }
        AlertDialog.Builder(this).setTitle("Edit task ${i+2}").setView(box).setNegativeButton("Batal",null).setPositiveButton("Simpan"){_,_->
            s.name=name.text.toString(); s.x=x.text.toString().toIntOrNull()?.coerceIn(0,100)?:s.x
            s.y=y.text.toString().toIntOrNull()?.coerceIn(0,100)?:s.y; s.delay=d.text.toString().toIntOrNull()?.coerceIn(0,60000)?:s.delay
            saveSteps(); renderSteps()
        }.show()
    }

    private fun runStep(i:Int) {
        if (TapService.instance==null) { Toast.makeText(this,"Aktifkan Accessibility dahulu",Toast.LENGTH_LONG).show(); return }
        val s=steps[i]
        statusText.text="Menjalankan ${s.name}..."
        android.os.Handler(mainLooper).postDelayed({
            TapService.instance?.tapAt(s.x/100f,s.y/100f)
            statusText.text="Selesai: ${s.name}"
        },s.delay.toLong())
    }

    private fun saveSteps() {
        val a=JSONArray()
        steps.forEach { a.put(JSONObject().put("name",it.name).put("x",it.x).put("y",it.y).put("delay",it.delay)) }
        prefs.edit().putString("steps",a.toString()).apply()
    }
    private fun loadSteps() {
        winX = prefs.getInt("winX", winX); winY = prefs.getInt("winY", winY)
        winColor = prefs.getString("winColor", winColor) ?: winColor
        winTolerance = prefs.getInt("winTolerance", winTolerance)
        val raw=prefs.getString("steps",null) ?: return
        try { val a=JSONArray(raw); for(i in 0 until a.length()){ val o=a.getJSONObject(i); steps.add(StepConfig(o.optString("name"),o.optInt("x",50),o.optInt("y",85),o.optInt("delay",500))) } } catch(_:Exception){}
    }

    private fun startAI() {
        if (TapService.instance==null) { Toast.makeText(this,"Aktifkan Accessibility dahulu",Toast.LENGTH_LONG).show(); startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); return }
        val mgr=getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mgr.createScreenCaptureIntent(),captureRequest)
    }
    @Deprecated("Deprecated")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==captureRequest && resultCode==Activity.RESULT_OK && data!=null){
            val i=Intent(this,CaptureService::class.java).putExtra("code",resultCode).putExtra("data",data)
            if(android.os.Build.VERSION.SDK_INT>=26) startForegroundService(i) else startService(i)
            autoIndex = 0
            statusText.text="Status: AI gameplay berjalan otomatis"
        }
    }
}
