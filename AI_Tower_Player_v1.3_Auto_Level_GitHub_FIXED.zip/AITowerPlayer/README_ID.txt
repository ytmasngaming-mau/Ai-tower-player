AI TOWER PLAYER v1.3 — GitHub Actions Ready

FITUR AUTO LEVEL (berdasarkan screenshot game yang dikirim):
1. Saat layar popup ROYAL DECREE / SMASH muncul, aplikasi mendeteksi tombol dan menekannya otomatis.
2. Saat bermain, sistem memindai garis bahaya untuk melepas sentuhan pada bagian gelap.
3. Saat layar TOWER SMASHED muncul, sistem menekan tombol Level (koordinat sekitar X 51.8%, Y 81.7%).
4. Saat popup SMASH level berikutnya muncul, sistem menekan SMASH (sekitar X 50%, Y 47.3%).
5. Siklus berulang untuk level selanjutnya sampai dihentikan pengguna.

PENTING:
- Ini otomasi berbasis pencocokan warna piksel di titik tombol, bukan computer vision/AI visual penuh.
- Koordinat dan warna diambil dari screenshot 691x1536. Resolusi, rasio layar, animasi, efek, atau desain game yang berbeda dapat membuat deteksi gagal.
- Untuk percobaan pertama, awasi proses. Pastikan game berada pada popup SMASH saat menekan MULAI AI GAMEPLAY.
- Jika mulai dari layar gameplay tanpa popup, versi ini belum punya tombol untuk melewati tahap popup awal.
- Sistem tidak dapat menjamin tamat semua level atau mengatasi level dengan mekanik khusus/layar iklan/konfirmasi lain.
- Accessibility dan izin screen capture harus diaktifkan. Android dapat menampilkan notifikasi foreground service.
- Fitur task tombol manual tambahan tetap tersedia.

BUILD APK VIA GITHUB:
1. Buat repository GitHub baru.
2. Ekstrak ZIP ini, masuk ke folder AITowerPlayer.
3. Upload ISI folder AITowerPlayer ke root repository (termasuk folder .github).
4. Buka tab Actions, pilih workflow Build AI Tower Player APK, lalu Run workflow.
5. Setelah selesai, buka hasil workflow dan unduh Artifact AI-Tower-Player-debug-APK.
6. Ekstrak artifact, lalu install app-debug.apk di Android.

Workflow menggunakan Java 17, Gradle 8.9, Android SDK 35, dan membangun assembleDebug.
